class AppRoutes {
  static const String splashScreen = '/SplashScreen';
  static const String loginScreen = '/loginScreen';
  static const String registionScreen = '/registionScreen';
  static const String homeScreen = '/homeScreen';
  static const String navBarScreen = '/NavBarScreen';
  static const String productDetalisScreen = '/ProductDetalisScreen';
  static const String cartScreen = '/CartScreen';
  static const String profileScreen = '/ProfileScreen';
  static const String favoriteScreen = '/FavoriteScreen';
  static const String allProductScreen = '/AllProductScreen';


}
